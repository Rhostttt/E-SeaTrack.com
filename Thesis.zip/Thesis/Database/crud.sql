-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2019 at 09:48 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `advertiser`
--

CREATE TABLE `advertiser` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advertiser`
--

INSERT INTO `advertiser` (`id`, `name`) VALUES
(1, 'Gapamakal kami baboy, Call or Text 0999555666 Look for Boboy'),
(2, 'Gapamakal kami manok, Call or Text 09193175452. Look for Glen'),
(3, 'Gapamakal kami pugo, Call or Text 09994577463. Look for Jayvee'),
(4, 'Gapamakal kami bangrus, Call or Text 09764567890. Look for Renato'),
(5, 'Gapamakal kami lukon, Call or Text 09764567890');

-- --------------------------------------------------------

--
-- Table structure for table `buyer`
--

CREATE TABLE `buyer` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_number` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buyer`
--

INSERT INTO `buyer` (`id`, `name`, `address`, `contact_number`) VALUES
(12, 'Jon Laurence Wenceslao', 'Bayuyan', '09293715754');

-- --------------------------------------------------------

--
-- Table structure for table `dried_fish`
--

CREATE TABLE `dried_fish` (
  `id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `per_unit` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dried_fish`
--

INSERT INTO `dried_fish` (`id`, `product_code`, `description`, `selling_price`, `per_unit`, `date`, `image`) VALUES
(45, 'drd-001', 'Lamayo', '100.00', 'Kilo', '2018-10-23', 'lamayo.jpg'),
(46, 'test', 'test', 'test', 'test', '2018-11-08', 'talong.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fruits`
--

CREATE TABLE `fruits` (
  `id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `per_unit` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fruits`
--

INSERT INTO `fruits` (`id`, `product_code`, `description`, `selling_price`, `per_unit`, `date`, `image`) VALUES
(2, 'frt-001', 'Apple', '25.00', 'Each', '2018-10-10', 'apple.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `grains`
--

CREATE TABLE `grains` (
  `id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `per_unit` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grains`
--

INSERT INTO `grains` (`id`, `product_code`, `description`, `selling_price`, `per_unit`, `date`, `image`) VALUES
(3, 'grn-001', 'Rice', '110.00', 'Per Kilo', '2018-09-22', 'rice.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `per_unit` varchar(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `product_code`, `description`, `selling_price`, `per_unit`, `date`) VALUES
(7, 'veg-001', 'Tomato', 'Php 50.00', 'Kilo', '2018-03-05'),
(8, 'veg-002', 'Carrots', 'Php 20.00', 'Kilo', '2018-02-19'),
(9, 'veg-003', 'Cabbage', 'Php 100.00', 'Kilo', '2018-03-01'),
(10, 'frt-001', 'Apple', 'Php 20.00', 'Kilo', '2018-03-06'),
(11, 'sfd-001', 'Bangrus', 'Php 35.00', 'Kilo', '2018-03-09'),
(12, 'spc-001', 'Curry Powder', 'Php 15.00', 'Each', '2018-02-01'),
(13, 'veg-004', 'Potato', 'Php 50.00', 'Kilo', '2018-03-05');

-- --------------------------------------------------------

--
-- Table structure for table `live_stocks`
--

CREATE TABLE `live_stocks` (
  `id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `per_unit` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `live_stocks`
--

INSERT INTO `live_stocks` (`id`, `product_code`, `description`, `selling_price`, `per_unit`, `date`, `image`) VALUES
(4, 'stck-001', 'Chicken', '100.00', 'Kilo', '2018-09-30', 'chicken.jpg'),
(6, 'stck-002', 'Beef', '150.00', 'Kilo', '2018-10-03', 'beef.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sea_foods`
--

CREATE TABLE `sea_foods` (
  `id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `per_unit` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sea_foods`
--

INSERT INTO `sea_foods` (`id`, `product_code`, `description`, `selling_price`, `per_unit`, `date`, `image`) VALUES
(4, 'sfd-001', 'Bangrus', '150.00', 'Kilo', '2018-10-01', 'bangrus.jpg'),
(6, 'sfd-002', 'Tilapia', '180.00', 'Kilo', '2018-10-04', 'tilapia.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sellers`
--

CREATE TABLE `sellers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_number` varchar(100) NOT NULL,
  `info` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sellers`
--

INSERT INTO `sellers` (`id`, `name`, `address`, `contact_number`, `info`) VALUES
(1, 'Boboy', 'Bayuyan', '0999555666', ''),
(2, 'Glen', 'San Dionisio', '09193175452', ''),
(3, 'Jayvee', 'Sara', '09994577463', ''),
(4, 'Renato', 'Batad', '09764567890', '');

-- --------------------------------------------------------

--
-- Table structure for table `spices`
--

CREATE TABLE `spices` (
  `id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `per_unit` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spices`
--

INSERT INTO `spices` (`id`, `product_code`, `description`, `selling_price`, `per_unit`, `date`, `image`) VALUES
(3, 'spc-001', 'Curry Powder', '30.00', 'Each', '2018-10-04', 'curry.jpg'),
(5, 'spc-002', 'Black Pepper', '50.00', 'Each', '2018-10-04', 'pepper.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(6, 'admin', 'admin@yahoo.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `vegetables`
--

CREATE TABLE `vegetables` (
  `id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `per_unit` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vegetables`
--

INSERT INTO `vegetables` (`id`, `product_code`, `description`, `selling_price`, `per_unit`, `date`, `image`) VALUES
(4, 'veg-001', 'Carrots', '50.00', 'Kilo', '2018-10-04', 'carroots.jpg'),
(6, 'veg-002', 'Cabbage', '70.00', 'Kilo', '2018-10-01', 'cabbage.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advertiser`
--
ALTER TABLE `advertiser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buyer`
--
ALTER TABLE `buyer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dried_fish`
--
ALTER TABLE `dried_fish`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fruits`
--
ALTER TABLE `fruits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grains`
--
ALTER TABLE `grains`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `live_stocks`
--
ALTER TABLE `live_stocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sea_foods`
--
ALTER TABLE `sea_foods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `spices`
--
ALTER TABLE `spices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vegetables`
--
ALTER TABLE `vegetables`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advertiser`
--
ALTER TABLE `advertiser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `buyer`
--
ALTER TABLE `buyer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `dried_fish`
--
ALTER TABLE `dried_fish`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `fruits`
--
ALTER TABLE `fruits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `grains`
--
ALTER TABLE `grains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `live_stocks`
--
ALTER TABLE `live_stocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `sea_foods`
--
ALTER TABLE `sea_foods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `sellers`
--
ALTER TABLE `sellers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `spices`
--
ALTER TABLE `spices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `vegetables`
--
ALTER TABLE `vegetables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
