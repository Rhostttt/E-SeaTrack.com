<?php
session_start();
	//initialize variables
$name = "";
$address = "";
$contact_number = "";
$id = 0;
$edit_state = false;

	//connect database
$db = mysqli_connect('localhost', 'root', '', 'crud');

	//if save button is clicked
if(isset($_POST['save'])){
	$name = $_POST['name'];
	$address = $_POST['address'];
	$contact_number = $_POST['contact_number'];
	
	$query = "INSERT INTO buyer (name, address, contact_number) VALUES ('$name', '$address', '$contact_number')";
	mysqli_query($db, $query);
	header('location: buyer.php'); //redirect to index.php after inserting
}
	//edit records
if (isset($_POST['update'])){
	$name = mysqli_real_escape_string($db,$_POST['name']);
	$address = mysqli_real_escape_string($db,$_POST['address']);
	$contact_number = mysqli_real_escape_string($db,$_POST['contact_number']);
	$id = mysqli_real_escape_string($db,$_POST['id']);
	
	mysqli_query($db, "UPDATE buyer SET name = '$name', address = '$address', contact_number = '$contact_number' WHERE id = $id");
	header('location: buyer.php');
}
	//delete records
if (isset($_GET['del'])){
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM buyer WHERE id = $id");
	header('location: buyer.php');
}

	//retrieve records
$results = mysqli_query($db, "SELECT * FROM buyer");

?>