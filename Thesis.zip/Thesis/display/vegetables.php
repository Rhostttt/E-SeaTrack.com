<?php include('../products/vegetables/vegetables_insert.php'); 

	//fetch the record to be updated
if (isset($_GET['edit'])){
	$id = $_GET['edit'];
	$edit_state = true;
	$rec = mysqli_query($db, "SELECT * FROM vegetables WHERE id = $id");
	$record = mysqli_fetch_array($rec);
	$name = $record['product_code'];
	$description = $record['description'];
	$selling_pirce = $record['selling_price'];
	$per_unit = $record['per_unit'];
	$date = $record['date'];
	$id = $record['id'];
	$results = mysqli_query($db, "SELECT * FROM vegetables");
}
header("Refresh: 15; url=driedfish.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Market Management Information System Support</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<style>
	body{
		background-color: White;
	}
  
	table{
		width:100%;
	}
	
	th{
		padding: 6px 3px;
		text-align: center;
		font-size: 22px;
		color: black;
		text-transform: uppercase;
		border-collapse: collapse;
	}

	td{
		padding: 15px;
		text-align: left;
		vertical-align:middle;
		color: black;
		font-size: 20px;
		border-collapse: collapse;
	}

	tr:nth-child(even){
		background-color: #8c8c8c;
	}
	
	tr:nth-child(odd){
		background-color:  #d9d9d9;
	}	
	
	th{
		text-align: center;
		font-size: 24px;
		background-color: #a6a6a6;
	}
	
	td{
		font-size: 30px;
	}
</style>
</head>

<body>

<!---Table--->
<center>
	<table>
		<thead>
			<tr>
				<th>Image</th>
				<th>Product Code</th>
				<th>Description</th>
				<th>Selling Price</th>
				<th>Per Unit</th>
				<th>Date</th>
			</tr>
		</thead>
		
		<center><h1><b>VEGETABLES / UTAN</b> &nbsp
		<font color = "red">(SMS Code: veges)</font></center><br>
		
		<tbody>
		<?php while ($row = mysqli_fetch_array($results)){ ?>
			<tr>
				<td><?php echo "<img src = '../images/".$row['image']. "'height='75px' width='75px'>" ?></td>
				<td><?php echo $row['product_code'] ?></td>
				<td><?php echo $row['description'] ?></td>
				<td><?php echo $row['selling_price'] ?></td>
				<td><?php echo $row['per_unit'] ?></td>
				<td><?php echo $row['date'] ?></td>
			</tr>
		<?php } ?>
		</tbody>
	</table>

</body>
</html>