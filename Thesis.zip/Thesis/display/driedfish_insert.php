<?php
session_start();
	//initialize variables
$product_code = "";
$description = "";
$selling_price = "";
$per_unit = "";
$date = "";
$id = 0;
$edit_state = false;

	//connect database
$db = mysqli_connect('localhost', 'root', '', 'crud');

	//if save button is clicked
if(isset($_POST['save'])){
	$product_code = $_POST['product_code'];
	$description = $_POST['description'];
	$selling_price = $_POST['selling_price'];
	$per_unit = $_POST['per_unit'];
	$date = $_POST['date'];
	
	$query = "INSERT INTO dried_fish (product_code, description, selling_price, per_unit, date) VALUES ('$product_code', '$description', '$selling_price', '$per_unit', '$date')";
	mysqli_query($db, $query);
	$_SESSION['msg'] = "Product Saved";
	header('location: dried_fish.php'); //redirect to index.php after inserting
}
	//edit records
if (isset($_POST['update'])){
	$product_code = mysqli_real_escape_string($_POST['product_code']);
	$description = mysqli_real_escape_string($_POST['description']);
	$selling_price = mysqli_real_escape_string($_POST['selling_price']);
	$per_unit = mysqli_real_escape_string($_POST['per_unit']);
	$date = mysqli_real_escape_string($_POST['date']);
	$id = mysqli_real_escape_string($_POST['id']);
	
	mysqli_query($db, "UPDATE dried_fish SET product_code = '$product_code', description = '$description', selling_price = '$selling_price', per_unit = '$per_unit', date = '$date'; WHERE id = $id");
	header('location: dried_fish.php');
}
	//delete records
if (isset($_GET['del'])){
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM dried_fish WHERE id = $id");
	$_SESSION['msg'] = "Product Deleted";
	header('location: dried_fish.php');
}

	//retrieve records
$results = mysqli_query($db, "SELECT * FROM dried_fish");

?>