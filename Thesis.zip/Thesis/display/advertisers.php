<?php
session_start();
//unset($_SESSION['count']);
$page = $_SERVER['PHP_SELF'];
$sec = "10";
if (!isset($_SESSION['count'])) {
  $_SESSION['count'] = 1;
} else {
  $id = $_SESSION['count']++;
//  echo $id;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Market Management Information System Support</title>
  <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" type = "text/css" href = "index_style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  body{
	  background-color: #4d94ff;
  }
table{
  width:100%;
  
}

td{
  padding: 15px;
  text-align: left;
  vertical-align:middle;
  font-weight: 300;
  font-size: 50%;
  color: black;
  border-bottom: solid 1px rgba(255,255,255,0.1);
  font-size: 20px;
 border-collapse: collapse;
  
}

tr:nth-child(even) {
		background-color: #bfbfbf;
		
	}
	
	th {
		text-align: center;
		font-size: 24px;
		background-color: #a6a6a6;
	}
	
	td{
		font-size: 30px;
	}
</style>
</head>

<body>
<?php

$db = mysqli_connect('localhost', 'root', '', 'crud');
$rec = mysqli_query($db, "SELECT * FROM advertiser");
$num_rows = mysqli_num_rows($rec);
//echo "$num_rows Rows\n";
if ($id >= $num_rows) 
{
	unset($_SESSION['count']);
	$id = $num_rows;
}

$results = mysqli_query($db, "SELECT * FROM advertiser WHERE id=" . $id);
?>
<!---Table--->
<center>
<br>
<table>
		<center><h1>ADVERTISING</h1></center>
		<?php while ($row = mysqli_fetch_array($results)){ 
			
		?>
			<tr>
				<td><?php echo $row['name'] ?></td>
			</tr>
		<?php } ?>
</table>

</body>
</html>