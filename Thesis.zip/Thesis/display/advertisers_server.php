<?php
session_start();
	//initialize variables
$name = "";
$address = "";
$contact_number = "";
$id = 0;
$edit_state = false;

	//connect database
$db = mysqli_connect('localhost', 'root', '', 'crud');

	//if save button is clicked
if(isset($_POST['save'])){
	$name = $_POST['name'];
	$address = $_POST['address'];
	$contact_number = $_POST['contact_number'];
	
	$query = "INSERT INTO advertiser (name, address, contact_number) VALUES ('$name', '$address', '$contact_number')";
	mysqli_query($db, $query);
	$_SESSION['msg'] = "Product Saved";
	header('location: advertiser.php'); //redirect to advertiser.php after inserting
}
	//edit records
if (isset($_POST['update'])){
	$name = mysqli_real_escape_string($_POST['name']);
	$address = mysqli_real_escape_string($_POST['address']);
	$contact_number = mysqli_real_escape_string($_POST['contact_number']);
	$id = mysqli_real_escape_string($_POST['id']);
	
	mysqli_query($db, "UPDATE advertiser SET name = '$name', address = '$address', contact_number = '$contact_number'; WHERE id = $id");
	header('location: advertiser.php');
}
	//delete records
if (isset($_GET['del'])){
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM advertiser WHERE id = $id");
	$_SESSION['msg'] = "Product Deleted";
	header('location: advertiser.php');
}

	//retrieve records
$results = mysqli_query($db, "SELECT * FROM advertiser");

?>