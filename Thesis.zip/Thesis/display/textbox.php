<!DOCTYPE html>
<html>
<body>

<textarea rows="10" cols="100">
At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies.
</textarea>

</body>
</html>