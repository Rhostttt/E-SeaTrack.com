<!DOCTYPE html>
<html lang="en">
<head>
  <title>Market Management Information System Support</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 450px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #171717;
      color: black;
      padding: 15px;
	  position:absolute;
	  bottom:0;
	  top: 595px;
	  width:100%;
	  height:50px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
	.modal-header{
		background-color: #171717;
	}
	.modal-title{
		color: white;
	}
	.input-group-btn{
		color: #171717;
	}
	
	* {
    box-sizing: border-box;
	}

	.column {
    float: left;
    width: 50%;
    padding: 5px;
	}

/* Clearfix (clear floats) */
	.row::after {
    content: "";
    clear: both;
    display: table;
	}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width: 500px) {
    .column {
        width: 100%;
    }
}

.btn {
    background-color: #2196F3;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    outline: none;
}

.dropdown {
    position: absolute;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd}

.dropdown:hover .dropdown-content {
    display: block;
}

.btn:hover, .dropdown:hover .btn {
    background-color: #0b7dda;
}

.footer{
	position: fixed;
}

table{
  width:90%;
  
}
.tbl-header{
  background-color: rgba(255,255,255,0.3);
 }
.tbl-content{
  height:300px;
  overflow-x:auto;
  margin-top: 0px;
  border: 1px solid rgba(255,255,255,0.3);
}
th{
  padding: 6px 3px;
  text-align: center;
  font-weight: 500;
  font-size: 22px;
  color: black;
  text-transform: uppercase;
  border-collapse: collapse;
  border: 1px solid black;
}
td{
  padding: 15px;
  text-align: left;
  vertical-align:middle;
  font-weight: 300;
  font-size: 18px;
  color: black;
  border-bottom: solid 1px rgba(255,255,255,0.1);
  font-size: 20px;
 border-collapse: collapse;
  border: 1px solid black;
}

tr:nth-child(even) {
		background-color: #bfbfbf;
		
	}
	
	th {
		text-align: center;
		font-size: 24px;
		background-color: #a6a6a6;
	}
	
	td{
		font-size: 30px;
	}
@-webkit-keyframes scroll{
	0%{
		-webkit-transform: translate(0, 0);
	}
	100%{
		-webkit-transform: translate(-100%, 0);
	}
}

.marquee{
	display: block;
	width:100%;
	white-space:nowrap;
	overflow:hidden;
	color:white;
}

.marquee span{
	display: inline-block;
	padding-left: 100%;
	-webkit-animation: scroll 35s infinite linear;
}
.navbar-brand{
	font-size: 30px;
	text-align: center;
}
#footer{
	width: 100%;
	height: 70px;
	position: absolute;
	bottom: 0;
	left: 0;
	background: #171717;
	color: white;
}
.clock{
			position: absolute;
			top: 25px;
			left: 1150px;
			transform: translateX(-50%) translateY(-50%);
			color: Red;
			font-size: 35px;
			padding: 0px 5px 0px 5px;
		}
</style>
</head>

<body>
<!---Navigation Bar--->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand">Market Management Information Support System</a>
    </div>
</nav>

	<center>
        			<div id="MyClockDisplay" class="clock"></div>
					<script type="text/javascript">

			function showTime(){
				var date = new Date();
				var h = date.getHours(); // 0 - 23
				var m = date.getMinutes(); // 0 - 59
				var s = date.getSeconds(); // 0 - 59
				var session = "AM";
				
				if(h >= 12){
					h = h - 12;
					session = "PM";
				}

				if(h == 0){
					h = 12;
				}

				h = (h < 10) ? "0" + h : h;
				m = (m < 10) ? "0" + m : m;
				s = (s < 10) ? "0" + s : s;

				var time = h + ":" + m + ":" + s + " " + session;
				document.getElementById("MyClockDisplay").innerText = time;
				document.getElementById("MyClockDisplay").textContent = time;

				setTimeout(showTime, 1000);
			}

			showTime();
	</script>
		</center>
		<!---overview of time end--->

        <iframe id="foo" frameborder="1" height="645" width="80%" align="left"></iframe>
        <script>
            (function() {
                var e = document.getElementById('foo'),
                    f = function( el, url ) {
                        el.src = url;
                    },
                    urls = [
                    'driedfish.php',
                    'fruits.php',
					'grains.php',
					'livestocks.php',
					'seafoods.php',
					'spices.php',
					'vegetables.php'
                    ],
                    i = 0,
                    l = urls.length;

                    (function rotation() {
                        if ( i != l-1 ) { 
                            i++
                        } else {
                            i = 0;
                        }
                        f( e, urls[i] );
                        setTimeout( arguments.callee, 15000 );
                    })();
            })();
        </script>
		
		  <iframe src="advertisers.php" frameborder="1" scrolling="no"  height="650" width="20%" align="right" style="background: gray;">
        </iframe>
		
<div id = "footer">
<h1 class="marquee"><span>Gusto mo mamangkot sang presyo? i-text ang <font color="red"><u>df</u></font> para sa uga; <font color="red"><u>fruits</u></font> para sa prutas; <font color="red"><u>gr</u></font> para sa mga bugas; <font color="red"><u>ls</u></font> para sa karne; <font color="red"><u>sf</u></font> para sa mga isda; <font color="red"><u>spices</u></font> para sa panakot; kag <font color="red"><u>veges</u></font> para sa mga ulutanon kag i-send sa <font color="red"><u>09666687267</u></font>. Madamo nga salamat.</span></h1>
</div>

</body>
</html>