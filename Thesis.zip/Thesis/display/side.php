<!DOCTYPE html>
<html lang="en">
<head>
  <title>Market Management Information System Support</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" type = "text/css" href = "index_style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
table{
  width:90%;
  
}
.tbl-header{
  background-color: rgba(255,255,255,0.3);
 }
.tbl-content{
  height:300px;
  overflow-x:auto;
  margin-top: 0px;
  border: 1px solid rgba(255,255,255,0.3);
}
th{
  padding: 6px 3px;
  text-align: center;
  font-weight: 500;
  font-size: 22px;
  color: black;
  text-transform: uppercase;
  border-collapse: collapse;
  border: 1px solid black;
}
td{
  padding: 15px;
  text-align: left;
  vertical-align:middle;
  font-weight: 300;
  color: black;
  font-size: 20px;
 border-collapse: collapse;
  border: 1px solid black;
}

tr:nth-child(even) {
		background-color: #bfbfbf;
		
	}
	
	th {
		text-align: center;
		font-size: 24px;
		background-color: #a6a6a6;
	}
	
	td{
		font-size: 30px;
	}
@-webkit-keyframes scroll{
	0%{
		-webkit-transform: translate(0, 0);
	}
	100%{
		-webkit-transform: translate(-100%, 0);
	}
}

.marquee{
	display: block;
	width:100%;
	white-space:nowrap;
	overflow:hidden;
	color:black;
}

.marquee span{
	display: inline-block;
	padding-left: 100%;
	-webkit-animation: scroll 35s infinite linear;
}
.navbar-brand{
	font-size: 30px;
	text-align: center;
}
#footer{
	width: 100%;
	height: 70px;
	position: absolute;
	bottom: 0;
	left: 0;
	background: gray;
	color: white;
}
.clock{
	position: absolute;
	top: 25px;
	left: 1150px;
	transform: translateX(-50%) translateY(-50%);
	color: Red;
	font-size: 35px;
	padding: 0px 5px 0px 5px;
}
</style>
</head>

<body>
<!---Navigation Bar--->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Market Management Information System Support</a>
    </div>
</nav>

	<center>
        			<div id="MyClockDisplay" class="clock"></div>
					<script type="text/javascript">

			function showTime(){
				var date = new Date();
				var h = date.getHours(); // 0 - 23
				var m = date.getMinutes(); // 0 - 59
				var s = date.getSeconds(); // 0 - 59
				var session = "AM";
				
				if(h >= 12){
					h = h - 12;
					session = "PM";
				}

				if(h == 0){
					h = 12;
				}

				h = (h < 10) ? "0" + h : h;
				m = (m < 10) ? "0" + m : m;
				s = (s < 10) ? "0" + s : s;

				var time = h + ":" + m + ":" + s + " " + session;
				document.getElementById("MyClockDisplay").innerText = time;
				document.getElementById("MyClockDisplay").textContent = time;

				setTimeout(showTime, 1000);
			}

			showTime();
	</script>
		</center>
		<!---overview of time end--->

     <iframe src="driedfish.php" frameborder="0" scrolling="no"
                                 height="645" width="800" align="left"> </iframe>  
    
     <iframe src="fruits.php" frameborder="0" scrolling="no"  height="645" width="500" align="right">
        </iframe>

<div id = "footer">
<h1 class="marquee"><span>Gusto mo mamangkot sang presyo? i-text ang <font color="red"><u>df</u></font> para sa uga; <font color="red"><u>fruits</u></font> para sa prutas; <font color="red"><u>gr</u></font> para sa mga bugas; <font color="red"><u>ls</u></font> para sa karne; <font color="red"><u>sf</u></font> para sa mga isda; <font color="red"><u>spices</u></font> para sa panakot; kag <font color="red"><u>veges</u></font> para sa mga ulutanon kag i-send sa <font color="red"><u>09666687267</u></font>. Madamo nga salamat.</span></h1>
</div>

</body>
</html>