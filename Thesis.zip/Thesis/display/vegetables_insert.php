<?php
session_start();
	//initialize variables
$product_code = "";
$description = "";
$selling_price = "";
$per_unit = "";
$date = "";
$id = 0;
$edit_state = false;

	//connect database
$db = mysqli_connect('localhost', 'root', '', 'crud');

	//if save button is clicked
if(isset($_POST['save'])){
	$product_code = $_POST['product_code'];
	$description = $_POST['description'];
	$selling_price = $_POST['selling_price'];
	$per_unit = $_POST['per_unit'];
	$date = $_POST['date'];
	
	$query = "INSERT INTO vegetables (product_code, description, selling_price, per_unit, date) VALUES ('$product_code', '$description', '$selling_price', '$per_unit', '$date')";
	mysqli_query($db, $query);
	$_SESSION['msg'] = "Product Saved";
	header('location: vegetables.php'); //redirect to index.php after inserting
}
	//edit records
if (isset($_POST['update'])){
	$product_code = mysqli_real_escape_string($_POST['product_code']);
	$description = mysqli_real_escape_string($_POST['description']);
	$selling_price = mysqli_real_escape_string($_POST['selling_price']);
	$per_unit = mysqli_real_escape_string($_POST['per_unit']);
	$date = mysqli_real_escape_string($_POST['date']);
	$id = mysqli_real_escape_string($_POST['id']);
	
	mysqli_query($db, "UPDATE vegetables SET product_code = '$product_code', description = '$description', selling_price = '$selling_price', per_unit = '$per_unit', date = '$date'; WHERE id = $id");
	$_SESSION['msg'] = "Product Updated";
	header('location: vegetables.php');
}
	//delete records
if (isset($_GET['del'])){
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM vegetables WHERE id = $id");
	$_SESSION['msg'] = "Product Deleted";
	header('location: vegetables.php');
}

	//retrieve records
$results = mysqli_query($db, "SELECT * FROM vegetables");

?>