<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Market Management Information System Support</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" type = "text/css" href = "register_style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 450px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
  </style>
</head>
<body>
<!---Navigation Bar--->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="Home.php">Market Management Information System Support</a>
    </div>
   <header class="header dark-bg">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>
      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">

          <!-- task notificatoin start -->
         
          <!-- task notificatoin end -->
          <!-- inbox notificatoin start-->
          
          <!-- inbox notificatoin end -->
          <!-- alert notification start-->
          		
          <!-- alert notification end-->
          <!-- user login dropdown start-->
          <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                            </span>
			</a>
            <ul class="dropdown-menu extended logout">
              <div class="log-arrow-up"></div>
              <li class="eborder-top">
              </li>	
            </ul>
          </li>
          <!-- user login dropdown end -->
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
  </div>
</nav>

  <section id="main-content">
      <section class="wrapper">
        <!--overview of time start-->
		<center>
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
			<b><p id="time"></p></b>
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
					<script type="text/javascript">
						var timestamp = '<?=time();?>';
							function updateTime(){
							$('#time').html(Date(timestamp));
							timestamp++;
							}
							$(function(){
							setInterval(updateTime, 1000);
							});
					</script>
            </ol>
          </div>
        </div>
		</center>
		<!---overview of time end--->
	
<center>
	<h1> User Registration </h1>
	<form method="post" action="register.php">
	<?php include('errors.php'); ?>
	<div class="input-group">
		<b>Username: </b>
		<input type="text" name="username" class = "form-control">
	</div>
	<div class="input-group">
		<b>Email: </b>
		<input type="email" name="email" class = "form-control">
	</div>
	<div class="input-group">
		<b> Password: </b>
		<input type="password" name="password_1" class = "form-control">
	</div>
	<div class="input-group">
		<b>Confirm password: </b>
		<input type="password" name="password_2" class = "form-control">
	</div>
	<div class="input-group"><br>
		<button type="submit" class="btn" name="reg_user">Register</button> &nbsp
		<button type="reset" class="btn">Reset</button>
	</div>
	</form>
</center>
	<footer class="container-fluid text-center">
	<p>Developed By: Jon Laurence Wenceslao, Glen Francisco, Rayza Andagan, Jessa Marie Bucane, Faith Rose Alkonga, Cristina Sinson</p>
	</footer>

</body>
</html>