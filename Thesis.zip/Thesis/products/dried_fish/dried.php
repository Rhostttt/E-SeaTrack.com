
<<!DOCTYPE html>
<html lang="en">
<head>
  <title>Market Management Information System Support</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css" integrity="sha384-G0fIWCsCzJIMAVNQPfjH08cyYaUtMwjJwqiRKxxE/rx96Uroj1BtIQ6MLJuheaO9" crossorigin="anonymous">
  <link rel = "stylesheet" type = "text/css" href = "products_style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 450px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #171717;
      color: white;
      padding: 15px;
	  position:fixed;
	  width:100%;
	  height:50px;
	  bottom: 5px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
	/*Table*/
	table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
	padding: 15px;
	}
	
	  /* NOTE: The styles were added inline because Prefixfree needs access to your styles and they must be inlined if they are on local disk! */
      /* reset */
* {
  margin: 0;
  padding: 0;
}

#wrapper {
  position: absolute;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

label {
  cursor: pointer;
}
label:focus {
  outline: none;
}

.menu {
  position: absolute;
  top: 0;
  left: 0;
  background:  #f1f1f1;
  width: 240px;
  height: 100%;
  transform: translate3d(-240px, 0, 0);
  transition: transform 0.35s;
  z-index: 21;
}
.menu label.menu-toggle {
  position: absolute;
  bottom: 538px;
  right: -50px;
  width: 50px;
  height: 45px;
  line-height: 0px;
  display: block;
  padding: 0;
  text-indent: -9999px;
  background:  #f1f1f1 url(https://cdn4.iconfinder.com/data/icons/wirecons-free-vector-icons/32/menu-alt-512.png) 50% 50%/25px 25px no-repeat;
}
.menu ul li > label {
  background: url(https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-arrow-right-b-128.png) 95% 50%/16px 16px no-repeat;
}
.menu ul li a, .menu ul li label {
  display: block;
  text-align: center;
  padding: 0 20px;
  line-height: 60px;
  text-decoration: none;
  color: #000;
}
.menu ul li a:hover, .menu ul li label:hover {
  color: #666;
}

/* hide inputs */
.menu-checkbox {
  display: none;
}

/* hide navigation icon for sublabels */
.menu .menu label.menu-toggle {
  background: none;
}

/* fade in checked menu */
.menu-checkbox:checked + .menu {
  transform: translate3d(0, 0, 0);
}

/* for show */
html, body {
  height: 100%;
}
</style>

</head>
<body>
<!---Navigation Bar--->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Market Management Information System Support</a>
    </div>
   <header class="header dark-bg">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>
      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">

          <!-- task notificatoin start -->
         
          <!-- task notificatoin end -->
          <!-- inbox notificatoin start-->
          
          <!-- inbox notificatoin end -->
          <!-- alert notification start-->
          		
          <!-- alert notification end-->
          <!-- user login dropdown start-->
          <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                
                            </span>
                            <span class="username">Administrator Settings</span>
                            <b class="caret"></b>
                        </a>
            <ul class="dropdown-menu extended logout">
              <div class="log-arrow-up"></div>
              <li class="eborder-top">
			  <br>
			    <a href="../../add_new_user.php"><i class="icon_profile"></i>Add New User</a>
				<hr>
			    <a href="../../change_password.php"><i class="icon_profile"></i>Change Password</a>
                <hr>
				<a href="../../index.php"><i class="icon_profile"></i>Logout</a>
				<br>
              </li>	
            </ul>
          </li>
          <!-- user login dropdown end -->
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
  </div>
</nav>

<section id="main-content">
      <section class="wrapper">
        <!--overview of time start-->
		<center>
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
			<b><p id="time"></p></b>
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
					<script type="text/javascript">
						var timestamp = '<?=time();?>';
							function updateTime(){
							$('#time').html(Date(timestamp));
							timestamp++;
							}
							$(function(){
							setInterval(updateTime, 1000);
							});
					</script>
            </ol>
          </div>
        </div>
		</center>
		<!---overview of time end--->

 <input type="checkbox" id="menu" name="menu" class="menu-checkbox">
  <div class="menu">
    <label class="menu-toggle" for="menu"><span>Toggle</span></label>
    <ul>
      <li>
        <a href="../../Home.php">Home</a>
      </li>
      <li>
        <label for="menu-2">Products</label>
        <input type="checkbox" id="menu-2" name="menu-2" class="menu-checkbox">
        <div class="menu">
          <label class="menu-toggle" for="menu-2"><span>Toggle</span></label>
          <ul>
		  <li>
            <label for="menu-2-9">Dried Fish</label>
              <input type="checkbox" id="menu-2-9" name="menu-2-9" class="menu-checkbox">
              <div class="menu">
                <label class="menu-toggle" for="menu-2-9"><span>Toggle</span></label>
                <ul>
                  <li>
                    <a href="dried_fish_add.php">Add</a>
                  </li>
                  <li>
                    <a href="dried_fish.php">View</a>
                  </li>
				 </ul>
			</div>
			</li>
           <li>
              <label for="menu-2-3">Fruits</label>
              <input type="checkbox" id="menu-2-3" name="menu-2-3" class="menu-checkbox">
              <div class="menu">
                <label class="menu-toggle" for="menu-2-8"><span>Toggle</span></label>
                <ul>
                  <li>
                    <a href="../../products/fruits/fruits_add.php">Add</a>
                  </li>
                  <li>
                    <a href="../../products/fruits/fruits.php">View</a>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <label for="menu-2-4">Grains</label>
              <input type="checkbox" id="menu-2-4" name="menu-2-4" class="menu-checkbox">
              <div class="menu">
                <label class="menu-toggle" for="menu-2-4"><span>Toggle</span></label>
                <ul>
                  <li>
                    <a href="../../products/grains/grains_add.php">Add</a>
                  </li>
                  <li>
                    <a href="../../products/grains/grains.php">View</a>
                  </li>
                </ul>
              </div>
            </li>
            <li>
             <label for="menu-2-5">Live Stocks</label>
              <input type="checkbox" id="menu-2-5" name="menu-2-5" class="menu-checkbox">
              <div class="menu">
                <label class="menu-toggle" for="menu-2-5"><span>Toggle</span></label>
                <ul>
                  <li>
                    <a href="../../products/live_stocks/live_stocks_add.php">Add</a>
                  </li>
                  <li>
                    <a href="../../products/live_stocks/live_stocks.php">View</a>
                  </li>
                </ul>
              </div>
            </li>
			<li>
              <label for="menu-2-6">Sea Foods</label>
              <input type="checkbox" id="menu-2-6" name="menu-2-6" class="menu-checkbox">
              <div class="menu">
                <label class="menu-toggle" for="menu-2-6"><span>Toggle</span></label>
                <ul>
                  <li>
                    <a href="../../products/sea_foods/sea_foods_add.php">Add</a>
                  </li>
                  <li>
                    <a href="../../products/sea_foods/sea_foods.php">View</a>
                  </li>
                </ul>
              </div>
            </li>
			<li>
              <label for="menu-2-7">Spices</label>
              <input type="checkbox" id="menu-2-7" name="menu-2-7" class="menu-checkbox">
              <div class="menu">
                <label class="menu-toggle" for="menu-2-7"><span>Toggle</span></label>
                <ul>
                  <li>
                    <a href="../../products/spices/spices_add.php">Add</a>
                  </li>
                  <li>
                    <a href="../../products/spices/spices.php">View</a>
                  </li>
                </ul>
              </div>
            </li>
			<li>
              <label for="menu-2-8">Vegetables</label>
              <input type="checkbox" id="menu-2-8" name="menu-2-8" class="menu-checkbox">
              <div class="menu">
                <label class="menu-toggle" for="menu-2-8"><span>Toggle</span></label>
                <ul>
                  <li>
                    <a href="../../vegetables/vegetables_add.php">Add</a>
                  </li>
                  <li>
                    <a href="../../vegetables/vegetables.php">View</a>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </li>
       <li>
        <label for="menu-3">Buyer</label>
        <input type="checkbox" id="menu-3" name="menu-3" class="menu-checkbox">
        <div class="menu">
          <label class="menu-toggle" for="menu-3"><span>Toggle</span></label>
          <ul>
            <li>
              <a href="../../buyer/buyer_add.php">Add</a>
            </li>
            <li>
              <a href="../../buyer/buyer.php">View</a>
            </li>
          </ul>
        </div>
      </li>      
      <li>
        <label for="menu-4">Seller</label>
        <input type="checkbox" id="menu-4" name="menu-4" class="menu-checkbox">
        <div class="menu">
          <label class="menu-toggle" for="menu-4"><span>Toggle</span></label>
          <ul>
            <li>
              <a href="../../seller/seller_add.php">Add</a>
            </li>
            <li>
              <a href="../../seller/seller.php">View</a>
            </li>
          </ul>
        </div>
      </li>      
      <li>
        <label for="menu-5">Advertisers</label>
        <input type="checkbox" id="menu-5" name="menu-5" class="menu-checkbox">
        <div class="menu">
          <label class="menu-toggle" for="menu-5"><span>Toggle</span></label>
          <ul>
            <li>
              <a href="../../advertiser/advertiser_add.php">Add</a>
            </li>
            <li>
              <a href="../../advertiser/advertiser.php">View</a>
            </li>
          </ul>
        </div>
      </li>
    </ul>
  </div>
</div><!-- #wrapper -->
<!---Table--->
<center>
<br>
<table>
<tr>
				<th>Image</th>
				<th>Product Code</th>
				<th>Description</th>
				<th>Selling Price</th>
				<th>Per Unit</th>
				<th>Date</th>
				<th colspan = "2">Action</th>
			</tr>
</tr>
<?php
	$db = mysqli_connect("localhost", "root", "", "crud");
	$sql = "SELECT * FROM dried_fish";
	$result = mysqli_query($db, $sql);
	while ($row = mysqli_fetch_array($result)) {
		echo "<tr>";
		
		echo "<td><img src = 'images/".$row['image']. "'height='50px' width='50px'></td>";
		echo "<td>" .$row['product_code']."</td>";
		echo "<td>" .$row['description']."</td>";
		echo "<td>" .$row['selling_price']."</td>";
		echo "<td>" .$row['per_unit']."</td>";
		echo "<td>" .$row['date']."</td>";
		echo "<td><a class='edit_btn' href='dried_fish_add.php?edit=" . $row['id'] . "'>Edit</a></td>";
		echo "<td><a class='del_btn' href='dried_fish_insert.php?del=" . $row['id'] . "'>Delete</a></td>";
		echo "</tr>";
	}
?>
</table>

	
</div>
</body>
</html>