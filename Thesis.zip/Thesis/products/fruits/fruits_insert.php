<?php
session_start();
	//initialize variables
$product_code = "";
$description = "";
$selling_price = "";
$per_unit = "";
$date = "";
$image = "";
$id = 0;
$edit_state = false;

	//connect database
$db = mysqli_connect('localhost', 'root', '', 'crud_new');

	//if save button is clicked
if(isset($_POST['save'])){
	$product_code = $_POST['product_code'];
	$description = $_POST['description'];
	$selling_price = $_POST['selling_price'];
	$per_unit = $_POST['per_unit'];
	$date = $_POST['date'];
	$image = $_POST['image'];
	
	//upload image
$msg = "";
	//if upload button is clicked
//if (isset($_POST['save'])){
	
	$target = "images/".basename($_FILES['image']['name']);

	$image = $_FILES['image']['name'];
	
	//connect to the database
	//$db = mysqli_connect("localhost", "root", "", "crud");
	//$qry=mysqli_query($db, "SELECT * from fruits where image='". $image."'");
	
	//Get all the submitted data from the form
	
	if (mysqli_num_rows($qry) >= 1){

		$sql = "UPDATE fruits SET product_code = '$product_code', description = '$description', selling_price = '$selling_price', per_unit = '$per_unit', date = '$date', image = '$image' WHERE id = $id";
	}
	else{
		//$sql = "INSERT INTO fruits (image) VALUES ('$image')";
	}
	mysqli_query($db, $sql); //stores the submitted data into the database table: images

	//Now let's move the uploaded image into the folder: images
	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)){
		$msg = "Image uploaded successfully";
	}else{
		$msg = "There was a problem uploading image";
		}
//}

	$query = "INSERT INTO fruits (product_code, description, selling_price, per_unit, date, image) VALUES ('$product_code', '$description', '$selling_price', '$per_unit', '$date', '$image')";
	mysqli_query($db, $query);
	header('location: fruits.php'); //redirect to index.php after inserting
}
	//edit records
if (isset($_POST['update'])){
	
	$target = "images/".basename($_FILES['image']['name']);

	$image = $_FILES['image']['name'];

	$product_code = mysqli_real_escape_string($db,$_POST['product_code']);
	$description = mysqli_real_escape_string($db,$_POST['description']);
	$selling_price = mysqli_real_escape_string($db,$_POST['selling_price']);
	$per_unit = mysqli_real_escape_string($db,$_POST['per_unit']);
	$date = mysqli_real_escape_string($db,$_POST['date']);
	$image = mysqli_real_escape_string($db,$_FILES['image']);
	$id = mysqli_real_escape_string($db,$_POST['id']);
	
	$target = "images/".basename($_FILES['image']['name']);

	$image = $_FILES['image']['name'];
	
	//connect to the database
	//$db = mysqli_connect("localhost", "root", "", "crud");
	//$qry=mysqli_query($db, "SELECT * from fruits where image='". $image."'");
	
	//Get all the submitted data from the form
	
	if (mysqli_num_rows($qry) >= 1){

		$sql = "UPDATE fruits SET product_code = '$product_code', description = '$description', selling_price = '$selling_price', per_unit = '$per_unit', date = '$date', image = '$image' WHERE id = $id";
	}
	else{
		//$sql = "INSERT INTO fruits (image) VALUES ('$image')";
	}
	mysqli_query($db, $sql); //stores the submitted data into the database table: images

	//Now let's move the uploaded image into the folder: images
	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)){
		$msg = "Image uploaded successfully";
	}else{
		$msg = "There was a problem uploading image";
		}
	
	mysqli_query($db, "UPDATE fruits SET product_code = '$product_code', description = '$description', selling_price = '$selling_price', per_unit = '$per_unit', date = '$date', image = '$image' WHERE id = $id");
	header('location: fruits.php');
}
	//delete records
if (isset($_GET['del'])){
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM fruits WHERE id = $id");
	header('location: fruits.php');
}

	//retrieve records
	$results = mysqli_query($db, "SELECT * FROM fruits");

?>