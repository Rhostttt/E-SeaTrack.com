<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Market Management Information Support System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel = "stylesheet" type = "text/css" href = "index_style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
/* Remove the navbar's default margin-bottom and rounded borders */ 
.navbar {
	margin-bottom: 0;
	border-radius: 0;
}
    
/* Set height of the grid so .sidenav can be 100% (adjust as needed) */
.row.content {
	height: 450px
}
    
/* Set gray background color and 100% height */
.sidenav {
	padding-top: 20px;
	background-color: #f1f1f1;
	height: 100%;
}
    
/* Set black background color, white text and some padding */
footer {
	background-color: #171717;
	color: white;
	padding: 15px;
	position:absolute;
	bottom:0;
	width:100%;
	height:50px;
}
    
/* On small screens, set height to 'auto' for sidenav and grid */
@media screen and (max-width: 767px) {
.sidenav {
	height: auto;
	padding: 15px;
}

.row.content {height:auto;} 
	}
		.modal-header{
			background-color: #171717;
		}
		.modal-title{
			color: white;
		}
		.input-group-btn{
			color: #171717;
		}
	
* {
	box-sizing: border-box;
}

/* Clearfix (clear floats) */
	.row::after {
	content: "";
	clear: both;
	display: table;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width: 500px) {
	.column {
	width: 100%;
	}
}

.btn {
	background-color: #2196F3;
	color: white;
	padding: 16px;
	font-size: 16px;
	border: none;
	outline: none;
}

.dropdown {
	position: absolute;
	display: inline-block;
}

.dropdown-content {
	display: none;
	position: absolute;
	background-color: #f1f1f1;
	min-width: 160px;
	z-index: 1;
}

.dropdown-content a {
	color: black;
	padding: 12px 16px;
	text-decoration: none;
	display: block;
}

.dropdown-content a:hover {
	background-color: #ddd
}

.dropdown:hover .dropdown-content {
	display: block;
}

.btn:hover, .dropdown:hover .btn {
	background-color: #0b7dda;
}
.column{
	margin-left: 25%;
	color: black;
}
</style>
</head>

<body>
<!---Navigation Bar--->
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
				<a class="navbar-brand" href="#">Market Management Information Support System</a>
		</div>
</nav>

<!---overview of time start---->
<center>
	<div class="row">
		<div class="col-lg-12">
			<ol class="breadcrumb">
				<b><p id="time"></p></b>
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
					<script type="text/javascript">
						var timestamp = '<?=time();?>';
						function updateTime(){
						$('#time').html(Date(timestamp));
						timestamp++;
						}
						$(function(){
						setInterval(updateTime, 1000);
						});
					</script>
			</ol>
		</div>
	</div>
</center>
<!---overview of time end--->

<div class = "header">
	<center>
	<h1>Market Management Information Support System</h1>
	<h1>Estancia, Iloilo</h1>
	</center>
</div>

<div class="container">
<div class = "row">
	<div class = "column">
		<img src = "images/admin.png" style="width: 15%; height: 30%; opacity: .8;">
		<br>
		<br>
		<!-- Trigger the modal with a button -->
		<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal_admin">Login as Admin</button>
		</a>
	</div>
</div>

  <!-- Modal -->
  <div class="modal fade" id="myModal_admin" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login as Admin</h4>
        </div>
		<center>
		<img src="images/admin.png" class="img-circle" alt="Cinque Terre" width="20%" height="15%">
        <div class="modal-body">
        <form method="post" action="login.php">
  	
			<?php include('errors.php'); ?>
				<div class="input-group">
					<label>Username: </label>
					<input class="form-control" type="text" name="username">
				</div>
				<div class="input-group">
					<label>Password: </label>
					<input class="form-control" type="password" name="password">
				</div>
				<br>
				<div class="input-group-btn">
					<button type="submit" class="btn" name="login_user">Login</button>
				</div>
				<p> <br>
					Not yet a member? <a href="register.php">Sign up</a>
				</p>
		</form>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

<footer class="container-fluid text-center">
<p>Developed By: Jon Laurence Wenceslao, Glen Francisco, Rayza Andagan, Jessa Marie Bucane, Faith Rose Alkonga, Cristina Sinson</p>
</footer>

</body>
</html>