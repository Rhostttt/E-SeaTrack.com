<?php
session_start();
	//initialize variables
$name = "";
$id = 0;
$edit_state = false;

	//connect database
$db = mysqli_connect('localhost', 'root', '', 'crud');

	//if save button is clicked
if(isset($_POST['save'])){
	$name = $_POST['name'];
	
	$query = "INSERT INTO advertiser (name) VALUES ('$name')";
	mysqli_query($db, $query);
	header('location: advertiser.php'); //redirect to index.php after inserting
}
	//edit records
if (isset($_POST['update'])){
	$name = mysqli_real_escape_string($db,$_POST['name']);
	$id = mysqli_real_escape_string($db,$_POST['id']);
	
	mysqli_query($db, "UPDATE advertiser SET name = '$name' WHERE id = $id");
	header('location: advertiser.php');
}
	//delete records
if (isset($_GET['del'])){
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM advertiser WHERE id = $id");
	header('location: advertiser.php');
}

	//retrieve records
$results = mysqli_query($db, "SELECT * FROM advertiser");

?>